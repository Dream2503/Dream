; Q2. Assembly Program to Find Smallest of Two 8-bit Numbers

MVI A, 20
MVI B, 30
CMP B

JM smaller
MOV A, B
STA 0
HLT

smaller: STA 0
HLT
