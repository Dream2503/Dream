; Q1. Assembly Program to Find Largest of Two 8-bit Numbers

MVI A, 30
MVI B, 30
CMP B

JM smaller
STA 0
HLT

smaller: MOV A, B
STA 0
HLT
