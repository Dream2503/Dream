#include <stdio.h>
#include <stdlib.h>

typedef struct {
	int id, start, finish;
} Activity;

int compartor(const void*, const void*);
int activity_selection(Activity*, int, Activity*);

int main() {
	int size, i;
	printf("Enter the total number of activities: ");
	scanf("%d", &size);
	Activity *activities = (Activity*)malloc(size * sizeof(Activity)), *selected = (Activity*)malloc(size * sizeof(Activity));

	for (i = 0; i < size; i++) {
		printf("Enter the id, starting and ending time of %dth element: ", i + 1);
		scanf("%d%d%d", &activities[i].id, &activities[i].start, &activities[i].finish);
	}
	int k = activity_selection(activities, size, selected);
	printf("The activities to select are:\n");

	for (i = 0; i < k; i++) {
		printf("ID: %d\tStart: %d\tFinish: %d\n", selected[i].id, selected[i].start, selected[i].finish);
	}
	return 0;
}

int comparator(const void *a, const void *b) {
	Activity lhs = *(Activity*)a, rhs = *(Activity*)b;
	
	if (lhs.finish < rhs.finish) {
		return -1;
	}
	if (lhs.finish > rhs.finish) {
		return 1;
	}
	return 0;
}

int activity_selection(Activity* activities, int size, Activity* selected) {
	int i, k = 0;
	qsort(activities, size, sizeof(Activity), comparator);
	selected[0] = activities[0];
	
	for (i = 1; i < size; i++) {
		if (activities[i].start >= selected[k].finish) {
			selected[++k] = activities[i];
		}
	}
	return k + 1;
}
